$(document).ready(function () {
  $(".ctnr-1-expr-text").counterUp({
    time: 500,
    delay: 1
  });
});